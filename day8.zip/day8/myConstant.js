var PIConst = 3.14;

exports.PI = PIConst;
