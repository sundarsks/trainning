var httpsModule = require("http");
var urlModule = require("url");
var fs = require("fs");
var studModule = require("./Student.js");


var server = httpsModule.createServer(f1);
server.listen(9090);

console.log("Https server started.. waiting requests");

function f1(request, response) {

    var requestPath = request.url;
    var pathNeeded = urlModule.parse(requestPath).pathname;
    console.log("path requested at server is: " + pathNeeded);
    response.writeHead(200, { "content-type": "text/html" });
    response.write("<html>");
    response.write("<body>");
    response.write("<h1> Student Lists </h1>");


    if (pathNeeded == "/register") {

        response.write("<h2> We will send an otp For registration....... try afterwards </h2>")
        response.write("<hr>");
    } else if (pathNeeded == "/AboutUs") {
        response.write("<hr>");
        response.write("<h2> We have office at chennai....... try afterwards </h2>")
        response.write("<hr>");
    } else if (pathNeeded == "/enquiry") {
        response.write("<h2> you call or email to the below mentioned mail id </h2>")
        response.write("<hr>");
    } else if (pathNeeded == "/") {
        var str = fs.readFileSync("./home.html");
        response.write(str);
    } else if (pathNeeded == "/list") {
        //Students display code
        var sm = new studModule.StudentManager();

        var stud1 = new studModule.Student(1, 'mani', 20, 30, 30);
        var stud2 = new studModule.Student(2, 'sundar', 30, 30, 30);
        var stud3 = new studModule.Student(3, 'surya', 70, 40, 50);
        sm.addStudent(stud1);
        sm.addStudent(stud2);
        sm.addStudent(stud3);

        var studs = sm.getAllStudents();
        response.write("<table>");
        for (i = 0; i < studs.length; i++) {
            response.write("<tr>");
            response.write("<td>" + studs[i].id + "</td>");
            response.write("<td>" + studs[i].name + "</td>");
            response.write("<td>" + studs[i].mark1 + "</td>");
            response.write("<td>" + studs[i].mark2 + "</td>");
            response.write("<td>" + studs[i].mark3 + "</td>");
            response.write("</tr>")
        }
        response.write("</table>");
    }

    response.write("</body>");
    response.write("</html");




}

