onmessage =  function(e){
    console.log("message received from main");

    var concat ="";
    for(i=0;i<e.data.num;i++){
        concat+= " "+ e.data.name
    }

    console.log("Posting message  back to main script");
    postMessage(concat);

}