var dem = require("./demo");

console.log(dem.welcome);

dem.print("hcl");

var cc = dem.defaultCircle;
console.log(cc.getArea());

