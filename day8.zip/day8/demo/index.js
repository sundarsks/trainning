var mc = require("./myConstant.js");


var greet = "Weclome to Node";

function echo(str){
    console.log(str.toUpperCase());
}

var c = {
    "radius" :5,
    "getArea": function(){
        return this.radius*this.radius*mc.PI;
    }
}

exports.welcome=greet;
exports.print=echo;
exports.defaultCircle = c;