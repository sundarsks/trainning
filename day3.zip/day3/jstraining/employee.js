function Employee(id,name,basic,grade){

    var userid=id;
    var username=name;
    var userbasic=basic;
    var usergrade=grade;

   

    this.setId=function(){
        if (isNaN(parseInt(id))) {
       
        userid=id;
        }
    }

    this.getId=function (id){
      
        return userid;
         
     }

    this.getName=function(name){
        return username;
    }

    this.setName= function(){
        if (typeof(name)=='string') {
       
        username=name;
        }
    }

    this.getBasic=function(basic){
        return userbasic;
    }

    this.setBasic= function(){
        if (isNaN(parseInt(basic))) {
       
        userbasic=basic;
        }
    }

    this.getGrade=function(grade){
        return usergrade;
    }

    this.setGrade= function(){
        if (typeof(grade)=='string') {
      
        usergrade=grade;
        }
    }

    var percent;
    this.getAllowance = function(){
        if(this.getGrade() == "A"){
            percent = 25;
        }

        if(this.getGrade()== "B"){
            percent = 18;
        }
        if(this.getGrade() == "C"){
            percent = 15;
        }

        return(this.getBasic()*percent/100)
    }
 this.getTax = function(){
     return(this.getBasic()*10/100);
 }

 this.getNetSalary = function(){
     return(this.getBasic()+ this.getAllowance()- this.getTax());
 }
    
}


var empId, empName, empBasic, empGrade, empAllowance, empTax, empNetPay;

function employeeDetails(){

var id = parseInt(window.document.forms[0].elements[0].value);
var name = window.document.forms[0].elements[1].value;
var basic = parseInt(window.document.forms[0].elements[2].value)
var grade = window.document.forms[0].elements[3].value;
var emp = new Employee(id,name,basic,grade);

if (isNaN(id) || isNaN(basic) || typeof (name) != 'string' || typeof (grade) != 'string') {
    alert('Invalid values')
} else {
    emp.setId(id);
    emp.setName(name);
    emp.setBasic(basic);
    emp.setGrade(grade);
    this.empId = emp.getId();
    this.empName= emp.getName();
    this.empBasic = emp.getBasic();
    this.empAllowance = emp.getAllowance();
    this.empTax = emp.getTax();
    this.empNetPay = emp.getNetSalary();

    formtableDatas();
    }
}
function formtableDatas() {
document.getElementById('idValue').innerText = this.empId;
document.getElementById('nameValue').innerText = this.empName;
document.getElementById('basicPayValue').innerText = this.empBasic;
document.getElementById('allowanceValue').innerText = this.empAllowance;
document.getElementById('taxValue').innerText = this.empTax;
document.getElementById('netSalaryValue').innerText = this.empNetPay;
}  
