var message = "Welcome to js";

function simple(){
    console.log("simple Happy day");
}

function Loan(a,b,c){
    this.loanAmount=a;
    this.duration=b;
    this.irate=c;
    this.getInterestAmount=function(){
        return this.loanAmount*this.duration*this.irate/100;
    }
}
var PI = 



exports.greet=simple;
exports.mymessage=message;
exports.Loan=Loan;