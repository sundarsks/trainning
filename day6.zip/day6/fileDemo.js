var myfs = require("fs");
var str = "my name is guru........ Frim chennai";
var rectangle = {
    "width": 20,
    "height":30
}

var str=JSON.stringify(rectangle);


//myfs.writeFileSync("myinfo.text", str);

myfs.writeFileSync("rect.txt", str);