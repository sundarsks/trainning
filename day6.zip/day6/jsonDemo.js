var account = {
    "id": 1234,
    "name":"mani",
    "balance": 50000.00
};

var str = JSON.stringify(account,null,5);
console.log(str);

var account2 = JSON.parse(str);
console.log(account2);
