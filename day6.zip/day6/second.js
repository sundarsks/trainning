var fm = require("./first.js");
console.log(fm.mymessage); 
fm.greet();
var myLoan = fm.Loan;

m1 = new myLoan(10000,5,4);

console.log(m1.loanAmount);
console.log(m1.duration);
console.log(m1.irate);
console.log(m1.getInterestAmount());


var c1= fm.favCircle;
console.log(c1);

x