function test(a){
        var b;
        b = 30;
        
        function test1(){
            console.log(a);
            console.log(b);
            return a+b;
            
        }
        return test1();
}

var x = test(10);
console.log(x);

var x1 = test(100);
console.log(x1);


