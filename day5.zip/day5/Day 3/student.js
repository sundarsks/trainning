function Student()
{
    this.name="";
    this.mark1=0;
    this.mark2=0;
    this.mark3=0;
    this.setName=function (n)
    {
        this.name=n;
    }
    this.setMark1=function(n1)
    {
        this.mark1=n1
    }
    this.setMark2=function(n2)
    {
        this.mark2=n2;
    }
    this.setMark3=function(n3)
    {
        this.mark3=n3;
    }
    this.getTotal=function()
    {

    }
    this.getAverage=function()
    {

    }
}