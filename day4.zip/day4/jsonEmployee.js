var emp1, emp2 , emp3;
function computeAllowance(){
    switch(this["emp grade"]){
        case 'A': return this["basic pay"]*0.25;
        case 'B': return this["basic pay"]*0.15;
        case 'C': return this["basic pay"]*0.10;
    }
}

function computeTax(){
    return this["basic pay"]*0.1;
}
function coumputeNet(){
    return this.getAllowance()+ this["basic pay"]-this.getTax()
}
emp1= {
    "emp id": 101,
    "emp name" : "sundar",
    "emp gender" : "Male",
    "basic pay": 300000,

    "emp grade": "A",
    "getAllowance": computeAllowance,
    "getTax": computeTax,
    "getNet": coumputeNet
}

for(emp in emp1){
    //console.log(emp +":" + emp1[emp]);
}

console.log(emp1.getAllowance());
console.log(emp1.getTax());
console.log(emp1.getNet());