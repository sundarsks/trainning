var circleObj;
circleObj = {
                "radius" : 10, 
                "midPoint-x" : 20 , 
                "midPoint y": 25, 
                "getArea": function(){
                    return this.radius*this.radius*3.14;
                }


            };

            circleObj1 = {
                "radius" : 5, 
                "midPoint-x" : 100 , 
                "midPoint y": 200, 
                "getArea": function(){
                    return this.radius*this.radius*3.14;
                },
                "getCircumference":f1

            };

            function f1(){
                return this.radius*2*3.14;
            }
            circleObj["getCircumference"]=f1;
            circleObj1["getCircumference"]=f1;
            
console.log(circleObj);
console.log(circleObj.getArea());
console.log(circleObj.radius);
console.log(circleObj["radius"]);
console.log(circleObj["midPoint-x"]);
console.log(circleObj["midPoint y"]);


var myProp ="midPoint-x";
console.log(circleObj[myProp]);

for(v in circleObj){
    console.log(v +":" + circleObj[v]);
    
}

console.log(circleObj.getCircumference());
console.log(circleObj1.getCircumference());


