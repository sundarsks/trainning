var maxFinder = function(a,b){
    if(a>b){
        return a;
    } else {
        return b;

    }
}
var maxFinder1 = (a,b) =>{
    if(a>b){
        return a;
    } else {
        return b;
    }
}

var simple=(a)=>{
    console.log(a);
}
var dummy =()=>{console.log(100)};
arr=[1,2,3,4,5];
arr.forEach(simple);

setInterval(dummy,1000);