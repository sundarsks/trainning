var myArray=[];
myArray.push(10);
myArray.push(20);
console.log(myArray);

myArray.unshift(5);
console.log(myArray);

myArray.pop();
myArray.shift();

console.log(myArray);
myArray.push(10,20,30,40);
console.log(myArray);

myArray.splice(2,1);
console.log(myArray);

myArray.reverse();
console.log(myArray);
