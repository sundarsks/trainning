var student

student = {
        "roll no": 1,
        "name": "sundar",
        "gender": "Male",
        "exam":{
            "mark1":70,
            "mark2":60,
            "mark3":90
        },
            "getTotal": computeTotal,
            "getAverage": computeAverage,
            "getRating":computeRating
    
    }


function computeTotal(){
    return this["exam"]["mark1"]+ this["exam"]["mark2"]+this["exam"]["mark3"];
}

function computeAverage(){
 return this.getTotal()/3;
}

function computeRating(){
    x= this.getAverage();
    if(x >= 90) {
        return "A+";
    } else if((x >= 80) &&(x<=89)) {
        return "A";
    }else if((x >= 70) &&(x<=79)) {
        return "B+";
    }else if((x >= 60) &&(x<=69)) {
        return "B";
    }else if((x >= 50) &&(x<=59)) {
        return "C";
    }else if(x<50) {
        return "Failed";
    }
}

console.log(student.getTotal());
console.log(student.getAverage());
console.log(student.getRating());