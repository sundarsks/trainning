
var loan=
{
    "id":100,
    "customer name":"MANI",
    "loanamount":450000,
    "duration":12,
    "interestRate":0.14,
    "repayment":[],
    "addrepayment":function(rp)
    {
        this.repayment.push(rp);
        console.log(this.repayment);
    },
    "getBalanceToBePaid":function(){

    },
    "getPaidAmount":function()
    {

    }
}
function Repayment(month,year,amount)
{   
    this.paymentmonth=month;
    this.paymentyear=year;
    this.paymentamount=amount;
}

