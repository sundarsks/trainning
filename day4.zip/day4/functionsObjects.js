var emp = {
        "name": "sundar"
}
var stud = {
    "name":"Mani"
}
function printUpper(){
    console.log(this.name.toUpperCase());
}

function countLength(a,b){
    console.log(this.name.length +a+b);
}

printUpper.call(emp);
printUpper.call(stud);

countLength.call(emp,10,30);
countLength.apply(stud,[100,200]);

function doPrint(a){
    console.log(a);
}

function printSum(x,y){
    console.log(x+y);
}
var bind500500 = printSum.bind(null, 500,600)
var bind1020 = printSum.bind(null,10,20);
bind1020();
bind500500();

var print10 = doPrint.bind(null,10);
print10();