var arr1 = [20, 30 ,80,10,100];

function sumHelper(s,e){
    return s+e;
}

function minHelper(m,e){
    if(m<e){
        return m;
    }
    return e;
}
function maxHelper(m,e){
if(m>e){
    return m;
} 
return e;
}

function avgHelper(a,e){
    return (a+e)/2;
}

var printElement = function(e){
    console.log(e);
}

arr1.forEach(printElement);
console.log(arr1);

var squareHelper = function(e){
    return e*e;
}
var arr2=arr1.map(squareHelper);
console.log(arr2);

function above1Checker(e){
    if(e >= 100){
        return true;
    } else {
        return false;
    }
}

var val = arr1.some(above1Checker);
var val1 = arr1.every(above1Checker);
var val2 = arr1.find(above1Checker);
console.log(val);
console.log(val1);
console.log(val2);




var result = arr1.reduce(sumHelper);
var result2 = arr1.reduce(minHelper);
var result3 = arr1.reduce(maxHelper);
var result4 = arr1.reduce(avgHelper);
//console.log(result);
//console.log(result);

//console.log(result2);
//console.log(result3);
//console.log(result4);