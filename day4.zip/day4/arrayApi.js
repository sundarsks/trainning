var arr1= ["HCL",
           "WIPRO",
            "Infosys",
            "CTS"];
var arr2 = [50,70,10,20,30,100,300];
arr1.sort();
arr2.sort();
console.log(arr2);
 var helper =  function(a,b) {
     return a-b;
 }

 arr2.sort(helper);
console.log(arr2);


